
import React, { createContext, useState } from 'react';
import all_product from '../Components/Assets/all_product';

export const ShopContext = createContext(null);

const getDefaultCart = () => {
    let cart = {};

    for (const product of all_product) {
        cart[product.id] = 0;
    }

    return cart;
};

const ShopContextProvider = (props) => {
    const [cartItems, setCartItems] = useState(getDefaultCart);
    const [refreshKey, setRefreshKey] = useState(0);

    const refreshShop = () => {
        setRefreshKey((prev) => {
            const nextKey = prev + 1;
            try {
                window.dispatchEvent(new CustomEvent('shop:refresh', { detail: { refreshKey: nextKey } }));
            } catch {
                // ignore
            }
            return nextKey;
        });
    };

    // Add product to cart
    const addToCart = (itemId) => {
        setCartItems((prev) => ({
            ...prev,
            [itemId]: (prev[itemId] || 0) + 1
        }));
    };

    // Remove one quantity
    const removeFromCart = (itemId) => {
        setCartItems((prev) => ({
            ...prev,
            [itemId]: Math.max(0, (prev[itemId] || 0) - 1)
        }));
    };

    // Calculate cart total
    const getTotalCartAmount = () => {
        let totalAmount = 0;

        for (const item in cartItems) {
            if (cartItems[item] > 0) {
                const itemInfo = all_product.find(
                    (product) => product.id === Number(item)
                );

                if (itemInfo) {
                    totalAmount += itemInfo.new_price * cartItems[item];
                }
            }
        }

        return totalAmount;
    };

    const getTotalCartItems = () => {
      let totalItem = 0;
      for(const item in cartItems)
      {
        if (cartItems[item]>0) {
          totalItem+= cartItems[item];
        }
      }
      return totalItem;
    } 
  

    const contextValue = {
      getTotalCartItems,
        getTotalCartAmount,
        all_product,
        cartItems,
        addToCart,
        removeFromCart,
        refreshKey,
        refreshShop
    };

    return (
        <ShopContext.Provider value={contextValue}>
            {props.children}
        </ShopContext.Provider>
    );
};

export default ShopContextProvider;
